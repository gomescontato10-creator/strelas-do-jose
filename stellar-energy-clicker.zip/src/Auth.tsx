import React, { useState } from 'react';
import * as Icons from 'lucide-react';

interface AuthProps {
  onLogin: (username: string) => void;
}

export function Auth({ onLogin }: AuthProps) {
  const [mode, setMode] = useState<'register' | 'login'>('register');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [month, setMonth] = useState('');
  const [day, setDay] = useState('');
  const [year, setYear] = useState('');
  const [error, setError] = useState('');

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (username.length < 3) return setError('O nome de usuário deve ter pelo menos 3 caracteres.');
    if (password.length < 8) return setError('A senha deve ter pelo menos 8 caracteres.');
    if (!month || !day || !year) return setError('Por favor, insira sua data de nascimento.');

    const users = JSON.parse(localStorage.getItem('roblox_users') || '{}');
    if (users[username]) {
      return setError('Nome de usuário já em uso.');
    }

    users[username] = { password, birthday: `${month}/${day}/${year}` };
    localStorage.setItem('roblox_users', JSON.stringify(users));
    onLogin(username);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!username || !password) return setError('Por favor, insira usuário e senha.');

    const users = JSON.parse(localStorage.getItem('roblox_users') || '{}');
    const user = users[username];
    if (!user || user.password !== password) {
      return setError('Usuário ou senha inválidos.');
    }

    onLogin(username);
  };

  const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

  return (
    <div className="h-screen w-full flex justify-center items-center font-sans bg-gradient-to-br from-indigo-900 via-purple-900 to-black relative">
      {/* Decorative stars / particles (simplified) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-10 left-10 w-32 h-32 bg-pink-500 rounded-full mix-blend-screen filter blur-[50px]"></div>
        <div className="absolute top-1/2 right-20 w-48 h-48 bg-cyan-500 rounded-full mix-blend-screen filter blur-[70px]"></div>
        <div className="absolute bottom-10 left-1/3 w-40 h-40 bg-purple-500 rounded-full mix-blend-screen filter blur-[60px]"></div>
      </div>

      <div className="w-[400px] bg-neutral-900/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-[0_0_50px_-12px_rgba(168,85,247,0.4)] overflow-hidden p-8 flex flex-col relative z-10">
        <div className="flex justify-center mb-4">
           <div className="p-3 bg-gradient-to-br from-cyan-400 to-purple-500 rounded-full shadow-lg shadow-purple-500/30">
              <Icons.Sparkles size={32} className="text-white" />
           </div>
        </div>

        <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 text-center mb-6">
          {mode === 'register' ? 'Cadastre-se e comece a se divertir!' : 'Entre na sua conta'}
        </h2>

        {error && <div className="bg-red-500/20 text-red-300 text-sm p-3 mb-4 rounded-lg border border-red-500/30 backdrop-blur-sm flex items-center gap-2"><Icons.AlertCircle size={16} />{error}</div>}

        <form onSubmit={mode === 'register' ? handleRegister : handleLogin} className="flex flex-col gap-4">
          
          {mode === 'register' && (
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-neutral-400 tracking-wide">Data de Nascimento</label>
              <div className="flex gap-2">
                <select value={month} onChange={e => setMonth(e.target.value)} className="flex-1 border border-neutral-700 hover:border-purple-500/50 transition-colors rounded-lg p-2.5 text-sm bg-neutral-800 text-white outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500">
                  <option value="" disabled>Mês</option>
                  {months.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
                <select value={day} onChange={e => setDay(e.target.value)} className="flex-1 border border-neutral-700 hover:border-purple-500/50 transition-colors rounded-lg p-2.5 text-sm bg-neutral-800 text-white outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500">
                  <option value="" disabled>Dia</option>
                  {Array.from({length: 31}, (_, i) => i + 1).map(d => <option key={d} value={d}>{d}</option>)}
                </select>
                <select value={year} onChange={e => setYear(e.target.value)} className="flex-1 border border-neutral-700 hover:border-purple-500/50 transition-colors rounded-lg p-2.5 text-sm bg-neutral-800 text-white outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500">
                  <option value="" disabled>Ano</option>
                  {Array.from({length: 100}, (_, i) => new Date().getFullYear() - i).map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
            </div>
          )}

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-neutral-400 tracking-wide">Usuário</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                 <Icons.User size={16} className="text-neutral-500" />
              </div>
              <input 
                type="text" 
                placeholder={mode === 'register' ? "Não use seu nome real" : "Usuário"} 
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full pl-10 border border-neutral-700 hover:border-purple-500/50 transition-colors rounded-lg p-3 text-sm bg-neutral-800 text-white outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 placeholder-neutral-500"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-neutral-400 tracking-wide">Senha</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                 <Icons.Lock size={16} className="text-neutral-500" />
              </div>
              <input 
                type="password" 
                placeholder={mode === 'register' ? "Pelo menos 8 caracteres" : "Senha"} 
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full pl-10 border border-neutral-700 hover:border-purple-500/50 transition-colors rounded-lg p-3 text-sm bg-neutral-800 text-white outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 placeholder-neutral-500"
              />
            </div>
          </div>

          <div className="mt-4">
            <button 
              type="submit" 
              className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-black text-lg py-3 rounded-lg shadow-lg shadow-purple-500/25 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
            >
              {mode === 'register' ? 'Cadastrar' : 'Entrar'}
            </button>
          </div>
        </form>

        <div className="mt-8 text-center bg-black/20 p-4 rounded-xl border border-white/5">
          {mode === 'register' ? (
            <div className="text-sm text-neutral-400 flex flex-col gap-1">
               <span>Já tem uma conta?</span>
               <button type="button" onClick={() => setMode('login')} className="text-cyan-400 font-bold hover:text-cyan-300 hover:underline transition-colors">Entrar</button>
            </div>
          ) : (
            <div className="text-sm text-neutral-400 flex flex-col gap-1">
               <span>Não tem uma conta?</span>
               <button type="button" onClick={() => setMode('register')} className="text-pink-400 font-bold hover:text-pink-300 hover:underline transition-colors">Cadastrar</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
