export const getBuildingCost = (baseCost: number, count: number): number => {
  return Math.floor(baseCost * Math.pow(1.15, count));
};

const SUFFIXES = ["", "k", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc", "UnD", "DuD", "TrD"];

export const formatNumber = (value: number): string => {
  if (value < 1000) return Math.floor(value).toString();
  const exponent = Math.floor(Math.log10(value) / 3);
  const shortValue = value / Math.pow(10, exponent * 3);
  const suffix = SUFFIXES[Math.min(exponent, SUFFIXES.length - 1)];
  return shortValue.toFixed(2).replace(/\.00$/, '') + suffix;
};
