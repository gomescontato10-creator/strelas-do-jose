export interface BuildingData {
  id: string;
  name: string;
  baseCost: number;
  baseProd: number;
  desc: string;
  icon: string;
}

export interface UpgradeData {
  id: string;
  name: string;
  desc: string;
  cost: number;
  reqType: 'building' | 'clicks';
  reqId?: string;
  reqAmount: number;
  icon: string;
}

export const BUILDINGS: BuildingData[] = [
  { id: 'b1', name: 'Auto-Clicker', baseCost: 15, baseProd: 0.1, desc: 'Automatically clicks for you.', icon: 'MousePointer2' },
  { id: 'b2', name: 'Solar Panel', baseCost: 100, baseProd: 1, desc: 'Harvests energy from the local star.', icon: 'Sun' },
  { id: 'b3', name: 'Plasma Reactor', baseCost: 1100, baseProd: 8, desc: 'Generates power through nuclear fusion.', icon: 'Zap' },
  { id: 'b4', name: 'Asteroid Miner', baseCost: 12000, baseProd: 47, desc: 'Extracts radioactive isotopes from asteroids.', icon: 'Gem' },
  { id: 'b5', name: 'Dyson Swarm', baseCost: 130000, baseProd: 260, desc: 'A swarm of satellites capturing solar energy.', icon: 'Orbit' },
  { id: 'b6', name: 'Warp Generator', baseCost: 1400000, baseProd: 1400, desc: 'Extracts vacuum energy from spacetime tears.', icon: 'Rocket' },
  { id: 'b7', name: 'Stellar Engine', baseCost: 20000000, baseProd: 7800, desc: 'Uses entire stars as fuel sources.', icon: 'Flame' },
  { id: 'b8', name: 'Black Hole Harvester', baseCost: 330000000, baseProd: 44000, desc: 'Taps into the accretion disk of a singularity.', icon: 'CircleDot' },
  { id: 'b9', name: 'Quasar Array', baseCost: 5100000000, baseProd: 260000, desc: 'Harnesses the most luminous active galactic nuclei.', icon: 'Sparkles' },
  { id: 'b10', name: 'Dimensional Rift', baseCost: 75000000000, baseProd: 1600000, desc: 'Siphons energy from parallel universes.', icon: 'Infinity' }
];

export const UPGRADES: UpgradeData[] = [];

// Procedurally generate upgrades for each building
BUILDINGS.forEach(b => {
    UPGRADES.push({
        id: `${b.id}_tier1`,
        name: `${b.name} Overclock`,
        desc: `Increases ${b.name} efficiency by 100%.`,
        cost: b.baseCost * 10,
        reqType: 'building',
        reqId: b.id,
        reqAmount: 10,
        icon: 'TrendingUp'
    });
    UPGRADES.push({
        id: `${b.id}_tier2`,
        name: `${b.name} Supercharge`,
        desc: `Increases ${b.name} efficiency by another 100%.`,
        cost: b.baseCost * 50,
        reqType: 'building',
        reqId: b.id,
        reqAmount: 50,
        icon: 'Zap'
    });
    UPGRADES.push({
        id: `${b.id}_tier3`,
        name: `${b.name} Transcendence`,
        desc: `Increases ${b.name} efficiency by another 100%.`,
        cost: b.baseCost * 500,
        reqType: 'building',
        reqId: b.id,
        reqAmount: 100,
        icon: 'Activity'
    });
});

export interface AchievementData {
  id: string;
  name: string;
  desc: string;
  reqType: 'energy' | 'clicks' | 'building' | 'totalBuildings';
  reqAmount: number;
  reqId?: string; // used if reqType is 'building'
  icon: string;
}

export interface PrestigeUpgradeData {
  id: string;
  name: string;
  desc: string;
  cost: number; // in prestige currency (e.g. Dark Matter)
  effectType: 'cps_multiplier' | 'click_multiplier' | 'starting_energy';
  effectValue: number;
  icon: string;
}

export const ACHIEVEMENTS: AchievementData[] = [
  { id: 'ach_c1', name: 'First Spark', desc: 'Click 100 times.', reqType: 'clicks', reqAmount: 100, icon: 'Mouse' },
  { id: 'ach_c2', name: 'Click Frenzy', desc: 'Click 1,000 times.', reqType: 'clicks', reqAmount: 1000, icon: 'Mouse' },
  { id: 'ach_e1', name: 'Getting Started', desc: 'Produce 1,000 total energy.', reqType: 'energy', reqAmount: 1000, icon: 'Zap' },
  { id: 'ach_e2', name: 'Power House', desc: 'Produce 1,000,000 total energy.', reqType: 'energy', reqAmount: 1000000, icon: 'Zap' },
  { id: 'ach_b1', name: 'Infrastructure', desc: 'Own 50 total buildings.', reqType: 'totalBuildings', reqAmount: 50, icon: 'Factory' },
  { id: 'ach_b2', name: 'Empire', desc: 'Own 200 total buildings.', reqType: 'totalBuildings', reqAmount: 200, icon: 'Factory' },
];

// Procedurally generate generic building achievements
BUILDINGS.forEach(b => {
  ACHIEVEMENTS.push({
    id: `ach_${b.id}_1`,
    name: `${b.name} Novice`,
    desc: `Own 10 ${b.name}s.`,
    reqType: 'building',
    reqId: b.id,
    reqAmount: 10,
    icon: b.icon
  });
  ACHIEVEMENTS.push({
    id: `ach_${b.id}_2`,
    name: `${b.name} Expert`,
    desc: `Own 50 ${b.name}s.`,
    reqType: 'building',
    reqId: b.id,
    reqAmount: 50,
    icon: b.icon
  });
});

export const PRESTIGE_UPGRADES: PrestigeUpgradeData[] = [
  { id: 'pu_1', name: 'Cosmic Awareness', desc: '+10% total CPS.', cost: 1, effectType: 'cps_multiplier', effectValue: 0.1, icon: 'Eye' },
  { id: 'pu_2', name: 'Dark Energy Core', desc: '+25% total CPS.', cost: 5, effectType: 'cps_multiplier', effectValue: 0.25, icon: 'Atom' },
  { id: 'pu_3', name: 'Click Synergy', desc: 'Click power +50%.', cost: 10, effectType: 'click_multiplier', effectValue: 0.5, icon: 'MousePointerClick' },
  { id: 'pu_4', name: 'Stellar Foundation', desc: 'Start with 100,000 energy.', cost: 20, effectType: 'starting_energy', effectValue: 100000, icon: 'BatteryCharging' }
];

// Special click upgrades
UPGRADES.push({ id: 'click_tier1', name: 'Ergonomic Mouse', desc: 'Clicking gains +1% of your CPS.', cost: 500, reqType: 'clicks', reqAmount: 50, icon: 'Mouse' });
UPGRADES.push({ id: 'click_tier2', name: 'Neural Link', desc: 'Clicking gains +5% of your CPS.', cost: 10000, reqType: 'clicks', reqAmount: 500, icon: 'Brain' });
UPGRADES.push({ id: 'click_tier3', name: 'Quantum Core', desc: 'Clicking gains +10% of your CPS.', cost: 1000000, reqType: 'clicks', reqAmount: 2000, icon: 'Cpu' });
