import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as Icons from 'lucide-react';
import { BUILDINGS, UPGRADES, ACHIEVEMENTS, PRESTIGE_UPGRADES } from './gameData';
import { getBuildingCost, formatNumber } from './utils';
import { useGame } from './useGame';
import { audio } from './audio';
import { Auth } from './Auth';
import * as Ably from 'ably';

let ablyClient: Ably.Realtime | null = null;
function initAbly(username: string) {
  if (!ablyClient) {
    try {
      ablyClient = new Ably.Realtime({ key: 'pRORYQ.uYTcnw:ylhIjT-CUV_5NA3yD5TeYkDjN00OR3zgGmBwqF2hqeU', clientId: username });
      // Removed presence enter to avoid capability rejection
    } catch (e) {
      console.warn("Ably init error", e);
    }
  }
}

function Icon({ name, className, size }: { name: string, className?: string, size?: number }) {
  const LucideIcon = (Icons as any)[name] || Icons.HelpCircle;
  return <LucideIcon className={className} size={size} />;
}

interface Particle { id: number; x: number; y: number; value: number; isCrit: boolean; }

function GameView({ username, onLogout }: { username: string, onLogout: () => void }) {
  const { 
     state, cps, clickPower, combo, loaded, recentAchievements, 
     manualClick, buyBuilding, buyUpgrade, buyPrestigeUpgrade, 
     calculatePrestigeGain, prestigeReset, hardReset 
  } = useGame(username);
  
  const [particles, setParticles] = useState<Particle[]>([]);
  const [hoveredUpgrade, setHoveredUpgrade] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);
  const [activeTab, setActiveTab] = useState<'upgrades' | 'achievements' | 'prestige'>('upgrades');
  const particleId = useRef(0);

  if (!loaded) return <div className="h-screen w-full bg-neutral-950 flex justify-center items-center text-white">Loading Matrix...</div>;

  const handleOrbClick = (e: React.MouseEvent) => {
    audio.init();
    const { gain, isCrit } = manualClick();
    audio.playClick(isCrit);
    
    if (isCrit) {
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 150);
    }

    const id = particleId.current++;
    // Get random offset around click
    const rx = (Math.random() - 0.5) * 40;
    const ry = (Math.random() - 0.5) * 40;
    setParticles(p => [...p, { id, x: e.clientX + rx, y: e.clientY + ry, value: gain, isCrit }]);
    setTimeout(() => {
      setParticles(p => p.filter(part => part.id !== id));
    }, 1000);
  };

  const handleBuyBuilding = (id: string, cost: number) => {
     audio.init();
     if (buyBuilding(id, cost)) {
        audio.playBuy();
     } else {
        audio.playError();
     }
  };

  const handleBuyUpgrade = (id: string, cost: number) => {
     audio.init();
     if (buyUpgrade(id, cost)) {
        audio.playUpgrade();
     } else {
        audio.playError();
     }
  };

  const handlePrestigeUpgrade = (id: string, cost: number) => {
     audio.init();
     if (buyPrestigeUpgrade(id, cost)) {
        audio.playUpgrade();
     } else {
        audio.playError();
     }
  };

  const currentPrestigeGain = calculatePrestigeGain();

  const availableUpgrades = UPGRADES.filter(u => {
    if (state.upgrades[u.id]) return false;
    if (u.reqType === 'building' && u.reqId) {
      return (state.buildings[u.reqId] || 0) >= u.reqAmount;
    }
    if (u.reqType === 'clicks') {
      return state.clicks >= u.reqAmount;
    }
    return false;
  });

  return (
    <div className={`h-screen w-full bg-neutral-950 flex flex-col lg:flex-row overflow-y-auto lg:overflow-hidden overflow-x-hidden text-neutral-100 font-sans selection:bg-cyan-500/30 ${isShaking ? 'animate-[shake_0.1s_ease-in-out_infinite]' : ''}`}>
      
      {/* Toast Notifications */}
      <div className="fixed bottom-4 left-4 z-50 flex flex-col gap-2 pointer-events-none">
        <AnimatePresence>
           {recentAchievements.map((ach, i) => (
             <motion.div
               key={`${ach}-${i}`}
               initial={{ opacity: 0, y: 50, scale: 0.9 }}
               animate={{ opacity: 1, y: 0, scale: 1 }}
               exit={{ opacity: 0, scale: 0.9 }}
               className="bg-neutral-800 border border-yellow-500/50 shadow-lg shadow-yellow-500/20 rounded-lg p-4 flex items-center gap-3"
             >
                <div className="bg-yellow-500/20 text-yellow-400 p-2 rounded-full">
                   <Icons.Trophy size={20} />
                </div>
                <div>
                   <div className="text-xs text-yellow-500/80 font-bold uppercase tracking-wider">Achievement Unlocked</div>
                   <div className="text-sm font-medium text-white">{ach}</div>
                </div>
             </motion.div>
           ))}
        </AnimatePresence>
      </div>

      {/* LEFT PANEL: THE CLICKER */}
      <div className="w-full lg:w-[340px] xl:w-[400px] shrink-0 flex flex-col items-center bg-neutral-950 border-[4px] border-blue-500 rounded-[24px] lg:m-2 relative z-10 px-4 lg:px-6 py-8 lg:py-10 order-1 lg:overflow-y-auto shadow-lg shadow-blue-500/20">
        {/* Decorative Grid BG */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none rounded-[20px]" />
        
        <div className="w-56 h-12 bg-gradient-to-b from-white to-neutral-400 mb-2 relative z-10 shadow-sm" />
        <div className="text-xs lg:text-sm tracking-[0.2em] text-cyan-400 uppercase font-semibold mb-8 lg:mb-12 drop-shadow-[0_0_8px_rgba(34,211,238,0.4)] flex items-center gap-2">
           {state.prestigeCurrency > 0 ? 'Dark Matter Era' : 'Cosmic Harvest'}
          {combo > 1 && (
            <motion.span 
              key={combo}
              initial={{ scale: 1.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-orange-400 font-black tracking-normal px-2 py-0.5 rounded border border-orange-500/50 bg-orange-500/10"
            >
              x{combo.toFixed(2)} COMBO!
            </motion.span>
          )}
        </div>

        <div className="w-full max-w-sm bg-neutral-900/80 backdrop-blur-sm border border-neutral-800 rounded-2xl p-4 lg:p-6 text-center mb-10 lg:mb-16 shadow-2xl relative z-10">
          <div className="text-xs lg:text-sm font-medium text-neutral-400 mb-1">CURRENT ENERGY</div>
          <div className="text-4xl lg:text-5xl font-mono font-bold text-white mb-2 tracking-tight">
            {formatNumber(state.energy)}
          </div>
          <div className="text-base lg:text-lg text-green-400 font-medium">
            {formatNumber(cps)} per second
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleOrbClick}
          style={{ touchAction: 'manipulation' }}
          className="relative w-48 h-48 lg:w-64 lg:h-64 rounded-full bg-gradient-to-br from-cyan-400 via-blue-600 to-indigo-900 shadow-[0_0_50px_rgba(34,211,238,0.4)] lg:shadow-[0_0_80px_rgba(34,211,238,0.4)] border border-cyan-300/50 flex-shrink-0 cursor-pointer overflow-hidden z-20 group"
        >
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 group-hover:opacity-40 transition-opacity" />
          <div className="absolute inset-0 rounded-full mix-blend-overlay bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-white/60 to-transparent" />
          <motion.div 
             animate={{ rotate: 360 }} 
             transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
             className="absolute inset-0 border-[4px] border-dashed border-white/20 rounded-full"
          />
        </motion.button>

        <div className="mt-10 lg:mt-auto w-full relative z-10">
           {state.prestigeCurrency > 0 && (
              <div className="mb-4 text-center font-mono text-purple-400 text-sm">
                 <Icons.Atom className="inline mb-1 mr-1" size={14}/>
                 {formatNumber(state.prestigeCurrency)} Dark Matter
              </div>
           )}
           <div className="flex gap-2">
             <button onClick={hardReset} className="flex-1 py-2 text-xs text-neutral-600 hover:text-red-400 uppercase tracking-widest font-bold transition-colors">
                Hard Reset
             </button>
             <button onClick={onLogout} className="flex-1 py-2 text-xs text-neutral-600 hover:text-white uppercase tracking-widest font-bold transition-colors">
                Log Out
             </button>
           </div>
        </div>
      </div>

      {/* MIDDLE PANEL: TABS, UPGRADES, ACHIEVEMENTS, PRESTIGE */}
      <div className="flex-1 flex flex-col lg:h-full bg-neutral-900 lg:overflow-y-auto order-3 lg:order-2 border-t lg:border-t-0 border-neutral-900">
        
        {/* TABS */}
        <div className="flex flex-row sticky top-0 z-20 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800 shadow-md">
           <button 
             onClick={() => setActiveTab('upgrades')}
             className={`flex-1 py-4 text-xs lg:text-sm font-bold uppercase tracking-wider transition-all flex justify-center items-center gap-2 ${activeTab === 'upgrades' ? 'text-cyan-400 border-b-2 border-cyan-400 bg-cyan-900/10' : 'text-neutral-500 hover:text-white hover:bg-neutral-800/50'}`}
           >
              <Icons.Zap size={16} /> <span className="hidden sm:inline">Upgrades</span>
           </button>
           <button 
             onClick={() => setActiveTab('achievements')}
             className={`flex-1 py-4 text-xs lg:text-sm font-bold uppercase tracking-wider transition-all flex justify-center items-center gap-2 ${activeTab === 'achievements' ? 'text-yellow-400 border-b-2 border-yellow-400 bg-yellow-900/10' : 'text-neutral-500 hover:text-white hover:bg-neutral-800/50'}`}
           >
              <Icons.Trophy size={16} /> <span className="hidden sm:inline">Achievements</span>
           </button>
           <button 
             onClick={() => setActiveTab('prestige')}
             className={`flex-1 py-4 text-xs lg:text-sm font-bold uppercase tracking-wider transition-all flex justify-center items-center gap-2 ${activeTab === 'prestige' ? 'text-purple-400 border-b-2 border-purple-400 bg-purple-900/10' : 'text-neutral-500 hover:text-white hover:bg-neutral-800/50'}`}
           >
              <Icons.Atom size={16} /> <span className="hidden sm:inline">Prestige</span>
           </button>
        </div>

        {/* TAB CONTENTS */}
        <div className="p-4 lg:p-6 flex-1">
          {/* UPGRADES TAB */}
           {activeTab === 'upgrades' && (
             <div className="flex flex-col">
                <h2 className="text-xl font-bold text-white mb-4 flex flex-shrink-0 items-center space-x-2">
                  <Icons.Zap className="text-yellow-400" size={20} />
                  <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">Research & Upgrades</span>
                </h2>
                
                <div className="min-h-[120px] lg:min-h-[130px] mb-6 p-5 bg-neutral-900 border border-neutral-700/50 rounded-xl shadow-lg flex flex-col justify-center transition-opacity relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                     <Icons.Microscope size={120} />
                  </div>
                  {hoveredUpgrade ? (() => {
                     const u = UPGRADES.find(x => x.id === hoveredUpgrade);
                     if (!u) return null;
                     const affordable = state.energy >= u.cost;
                     return (
                        <div className="relative z-10 w-full">
                          <div className="flex justify-between items-start mb-2 w-full gap-4">
                            <div className="font-bold text-lg text-white flex items-center gap-2">
                               <Icon name={u.icon} className={affordable ? 'text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]' : 'text-neutral-500'} size={20} />
                               <span className="tracking-wide break-words">{u.name}</span>
                            </div>
                            <div className={`text-sm shrink-0 font-mono font-bold flex items-center gap-1 ${affordable ? 'text-green-400' : 'text-red-400'}`}>
                              <Icons.Database size={14} /> {formatNumber(u.cost)}
                            </div>
                          </div>
                          <div className="text-sm text-neutral-300 leading-relaxed font-medium mb-2">{u.desc}</div>
                          {u.reqType && (
                            <div className="text-xs text-neutral-500 flex items-center gap-1 mt-1 font-mono">
                               <Icons.Unlock size={12} className="text-yellow-500" />
                               Requires: <span className="text-neutral-400 ml-1">{u.reqType === 'building' ? `${u.reqAmount} ${(BUILDINGS.find(b => b.id === u.reqId)?.name || 'Building')}s` : `${u.reqAmount} Clicks`}</span>
                            </div>
                          )}
                        </div>
                     );
                  })() : (
                     <div className="text-neutral-500 text-sm text-center italic flex flex-col items-center gap-2 relative z-10">
                        <Icons.MousePointer2 size={24} className="opacity-50 text-cyan-400" />
                        Hover or tap an upgrade to reveal its secrets.
                     </div>
                  )}
                </div>

                <div className="flex flex-wrap gap-3">
                  {availableUpgrades.length === 0 && (
                     <div className="text-neutral-500 text-sm italic w-full text-center py-8">No upgrades available. Keep expanding your empire!</div>
                  )}
                  {availableUpgrades.map((u, i) => {
                    const affordable = state.energy >= u.cost;
                    const colors = [
                      'text-cyan-400 border-cyan-400/50 hover:border-cyan-300 hover:shadow-[0_0_15px_rgba(34,211,238,0.4)] hover:bg-cyan-900/30',
                      'text-indigo-400 border-indigo-400/50 hover:border-indigo-300 hover:shadow-[0_0_15px_rgba(129,140,248,0.4)] hover:bg-indigo-900/30',
                      'text-fuchsia-400 border-fuchsia-400/50 hover:border-fuchsia-300 hover:shadow-[0_0_15px_rgba(232,121,249,0.4)] hover:bg-fuchsia-900/30',
                      'text-rose-400 border-rose-400/50 hover:border-rose-300 hover:shadow-[0_0_15px_rgba(251,113,133,0.4)] hover:bg-rose-900/30',
                      'text-emerald-400 border-emerald-400/50 hover:border-emerald-300 hover:shadow-[0_0_15px_rgba(52,211,153,0.4)] hover:bg-emerald-900/30',
                      'text-amber-400 border-amber-400/50 hover:border-amber-300 hover:shadow-[0_0_15px_rgba(251,191,36,0.4)] hover:bg-amber-900/30'
                    ];
                    const colorClasses = colors[i % colors.length];

                    return (
                      <button
                        key={u.id}
                        onMouseEnter={() => setHoveredUpgrade(u.id)}
                        onMouseLeave={() => setHoveredUpgrade(null)}
                        onClick={() => {
                          if (affordable) handleBuyUpgrade(u.id, u.cost);
                        }}
                        className={`relative w-14 h-14 rounded-xl bg-neutral-900 border-2 ${affordable ? `${colorClasses} cursor-pointer` : 'border-neutral-800 opacity-50 cursor-not-allowed'} flex items-center justify-center transition-all group`}
                      >
                        <Icon name={u.icon} className={`relative z-10 ${affordable ? 'drop-shadow-[0_0_5px_currentColor] scale-110' : 'text-neutral-600'} transition-transform group-hover:scale-125`} size={24} />
                      </button>
                    );
                  })}
                </div>
             </div>
          )}

          {/* ACHIEVEMENTS TAB */}
          {activeTab === 'achievements' && (
             <div>
                <h2 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
                  <Icons.Trophy className="text-yellow-400" size={20} />
                  <span>Completed Achievements ({Object.keys(state.achievements).length} / {ACHIEVEMENTS.length})</span>
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                   {ACHIEVEMENTS.map(ach => {
                      const unlocked = !!state.achievements[ach.id];
                      return (
                         <div key={ach.id} className={`flex items-center gap-3 p-3 rounded border ${unlocked ? 'bg-neutral-800/80 border-yellow-500/30' : 'bg-neutral-900/50 border-neutral-800 opacity-50'}`}>
                            <div className={`w-10 h-10 rounded flex justify-center items-center shrink-0 ${unlocked ? 'bg-yellow-500/20 text-yellow-400' : 'bg-neutral-800 text-neutral-600'}`}>
                               <Icon name={ach.icon} size={20} />
                            </div>
                            <div>
                               <div className={`text-sm font-bold ${unlocked ? 'text-white' : 'text-neutral-500'}`}>{unlocked ? ach.name : '???'}</div>
                               <div className="text-xs text-neutral-500">{unlocked ? ach.desc : 'Condition unknown'}</div>
                            </div>
                         </div>
                      )
                   })}
                </div>
             </div>
          )}

          {/* PRESTIGE TAB */}
          {activeTab === 'prestige' && (
             <div>
                <div className="bg-purple-900/20 border border-purple-500/30 rounded-xl p-6 text-center mb-8">
                   <h2 className="text-2xl font-black text-purple-400 mb-2">Dark Matter Rebirth</h2>
                   <p className="text-neutral-300 text-sm mb-6 max-w-lg mx-auto">
                     Collapse your current universe to harness its accumulated energy into Dark Matter. 
                     This will reset your energy, clicks, upgrades, and structures, but you keep your achievements and Dark Matter.
                   </p>
                   
                   <div className="flex flex-col sm:flex-row justify-center items-center gap-6 mb-6">
                      <div className="bg-neutral-900 border border-neutral-800 rounded p-4 w-48">
                         <div className="text-xs text-neutral-500 mb-1 font-bold tracking-wider">LIFETIME ENERGY</div>
                         <div className="text-xl font-mono text-white">{formatNumber(state.lifetimeEnergy)}</div>
                      </div>
                      <Icons.ArrowRight className="text-neutral-600 hidden sm:block" />
                      <div className="bg-neutral-900 border border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.2)] rounded p-4 w-48">
                         <div className="text-xs text-purple-400 mb-1 font-bold tracking-wider">DARK MATTER GAIN</div>
                         <div className="text-xl font-mono text-white">+{formatNumber(currentPrestigeGain)}</div>
                      </div>
                   </div>

                   <button 
                     onClick={() => prestigeReset()}
                     disabled={currentPrestigeGain <= 0}
                     className={`px-8 py-3 rounded text-sm font-bold tracking-widest uppercase transition-all ${currentPrestigeGain > 0 ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-[0_0_20px_rgba(168,85,247,0.4)]' : 'bg-neutral-800 text-neutral-600 cursor-not-allowed'}`}
                   >
                      Initiate Big Crunch
                   </button>
                </div>

                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                   <Icons.Atom className="text-purple-400 drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]" size={24} />
                   <span className="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">Dark Matter Upgrades</span>
                </h3>
                {state.prestigeCurrency === 0 && currentPrestigeGain === 0 && Object.keys(state.prestigeUpgrades).length === 0 ? (
                   <div className="text-sm text-neutral-500 italic p-6 text-center border border-neutral-800/50 rounded-xl bg-neutral-900/50">You must harvest more energy to witness the birth of Dark Matter.</div>
                ) : (
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {PRESTIGE_UPGRADES.map((pu, i) => {
                         const maxed = !!state.prestigeUpgrades[pu.id];
                         const affordable = state.prestigeCurrency >= pu.cost && !maxed;

                         return (
                            <button 
                               key={pu.id}
                               disabled={maxed || !affordable}
                               onClick={() => handlePrestigeUpgrade(pu.id, pu.cost)}
                               className={`flex items-start gap-4 p-5 rounded-xl border-2 text-left transition-all relative overflow-hidden group ${maxed ? 'bg-purple-900/20 border-purple-500/50 opacity-100' : affordable ? 'bg-neutral-800/80 hover:bg-neutral-700 border-purple-500/30 hover:border-purple-400 hover:shadow-[0_0_20px_rgba(168,85,247,0.2)] cursor-pointer' : 'bg-neutral-900/80 border-neutral-800 opacity-60 cursor-not-allowed'}`}
                            >
                               <div className={`absolute inset-0 bg-gradient-to-r from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none rounded-xl`} />
                               <div className={`w-12 h-12 rounded-full flex justify-center items-center shrink-0 shadow-lg relative z-10 transition-transform group-hover:scale-110 ${maxed ? 'bg-purple-500 text-white shadow-purple-500/40' : affordable ? 'bg-purple-900 text-purple-300 shadow-purple-900/40' : 'bg-neutral-800 text-neutral-500'}`}>
                                  <Icon name={pu.icon} size={24} />
                               </div>
                               <div className="flex-1 relative z-10">
                                  <div className={`text-base font-bold ${maxed ? 'text-purple-300' : 'text-white group-hover:text-purple-100 transition-colors'}`}>{pu.name}</div>
                                  <div className="text-xs text-neutral-400 mb-3 font-medium">{pu.desc}</div>
                                  <div className={`text-xs font-mono font-bold flex items-center gap-1 py-1 px-2 rounded w-fit ${maxed ? 'bg-purple-900/50 text-purple-300 border border-purple-500/50' : affordable ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-red-500/10 text-red-400 border border-red-500/30'}`}>
                                     {maxed ? <><Icons.CheckCircle2 size={12} className="mr-1"/> ACQUIRED</> : <><Icons.Atom size={12}/> {pu.cost} Dark Matter</>}
                                  </div>
                               </div>
                            </button>
                         )
                      })}
                   </div>
                )}
             </div>
          )}
        </div>

        {/* Stats Panel */}
        <div className="p-4 lg:p-6 mt-auto">
           <h3 className="text-sm font-bold flex items-center gap-2 text-neutral-500 mb-4 uppercase tracking-widest"><Icons.Activity size={16} /> Global Statistics</h3>
           <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              <div className="bg-neutral-900 border-b-2 border-yellow-500/50 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                 <div className="text-xs text-neutral-400 mb-1 flex items-center gap-1"><Icons.Zap size={14} className="text-yellow-500"/> Total Energy (Run)</div>
                 <div className="font-mono text-base lg:text-md text-white font-bold">{formatNumber(state.totalEnergy)}</div>
              </div>
              <div className="bg-neutral-900 border-b-2 border-cyan-500/50 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                 <div className="text-xs text-neutral-400 mb-1 flex items-center gap-1"><Icons.MousePointerClick size={14} className="text-cyan-500"/> Total Manual Clicks</div>
                 <div className="font-mono text-base lg:text-md text-white font-bold">{formatNumber(state.clicks)}</div>
              </div>
              <div className="bg-neutral-900 border-b-2 border-orange-500/50 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                 <div className="text-xs text-neutral-400 mb-1 flex items-center gap-1"><Icons.Factory size={14} className="text-orange-500"/> Structures Built</div>
                 <div className="font-mono text-base lg:text-md text-white font-bold">
                    {Object.values(state.buildings).reduce((a: number, b: number) => a + b, 0)}
                 </div>
              </div>
              <div className="bg-neutral-900 border-b-2 border-purple-500/50 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                 <div className="text-xs text-neutral-400 mb-1 flex items-center gap-1"><Icons.FlaskConical size={14} className="text-purple-500"/> Upgrades Researched</div>
                 <div className="font-mono text-base lg:text-md text-white font-bold">
                    {Object.keys(state.upgrades).length} / {UPGRADES.length}
                 </div>
              </div>
           </div>
        </div>
      </div>

      {/* RIGHT PANEL: BUILDINGS (ORDER 2 on Mobile) */}
      <div className="w-full lg:w-[320px] xl:w-[380px] shrink-0 lg:h-full bg-neutral-950 lg:border-l border-neutral-900 flex flex-col lg:overflow-y-auto align-top shadow-none lg:shadow-[-10px_0_30px_rgba(0,0,0,0.5)] z-20 order-2 lg:order-3 pt-6 lg:pt-0">
        <div className="lg:sticky top-0 bg-neutral-950/80 backdrop-blur-md p-4 border-b border-neutral-800 z-10">
           <h2 className="text-lg font-bold text-white uppercase tracking-wider flex items-center gap-2">
             <Icons.Factory className="text-neutral-400" size={18}/>
             Construct
           </h2>
        </div>
        
        <div className="flex-1 pb-6 lg:pb-0">
          {BUILDINGS.map((b, i) => {
             const count = state.buildings[b.id] || 0;
             const cost = getBuildingCost(b.baseCost, count);
             const affordable = state.energy >= cost;

             const rainbowColors = [
                'text-pink-400 group-hover:text-pink-300 drop-shadow-[0_0_8px_rgba(244,114,182,0.6)]',
                'text-indigo-400 group-hover:text-indigo-300 drop-shadow-[0_0_8px_rgba(129,140,248,0.6)]',
                'text-cyan-400 group-hover:text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.6)]',
                'text-emerald-400 group-hover:text-emerald-300 drop-shadow-[0_0_8px_rgba(52,211,153,0.6)]',
                'text-amber-400 group-hover:text-amber-300 drop-shadow-[0_0_8px_rgba(251,191,36,0.6)]',
                'text-rose-400 group-hover:text-rose-300 drop-shadow-[0_0_8px_rgba(251,113,133,0.6)]',
                'text-violet-400 group-hover:text-violet-300 drop-shadow-[0_0_8px_rgba(167,139,250,0.6)]'
             ];
             const iconColor = rainbowColors[i % rainbowColors.length];
             const isHoverableAffordable = affordable ? 'hover:bg-neutral-800/80 hover:pl-5 cursor-pointer border-l-4 border-l-transparent hover:border-l-cyan-400' : 'bg-neutral-950/50 opacity-60 cursor-not-allowed border-l-4 border-l-transparent';

             return (
               <button 
                 key={b.id}
                 onClick={() => { if(affordable) handleBuyBuilding(b.id, b.baseCost) }}
                 disabled={!affordable}
                 className={`w-full flex items-center p-4 border-b border-neutral-900 transition-all text-left relative overflow-hidden group ${isHoverableAffordable}`}
               >
                  <div className={`text-4xl w-14 lg:w-16 flex justify-center items-center shrink-0 transition-transform group-hover:scale-110 ${affordable ? iconColor : 'text-neutral-600 group-hover:text-neutral-500'}`}>
                    <Icon name={b.icon} size={28} />
                  </div>
                  
                  <div className="flex-1 pr-4 min-w-0 relative z-10">
                    <div className="font-bold text-base lg:text-lg text-white group-hover:text-cyan-300 transition-colors truncate">{b.name}</div>
                    <div className={`text-xs lg:text-sm font-mono flex items-center gap-1 font-bold ${affordable ? 'text-green-400' : 'text-red-400'}`}>
                      <Icons.Database size={12}/> {formatNumber(cost)} Energy
                    </div>
                  </div>
                  
                  <div className={`text-3xl lg:text-4xl font-black absolute right-4 lg:right-2 top-2 lg:top-1 pointer-events-none transition-all group-hover:scale-110 ${count > 0 ? 'text-neutral-700/80 group-hover:text-neutral-600/80 drop-shadow-sm' : 'text-neutral-800/50 group-hover:text-neutral-700/50'}`}>
                     {count}
                  </div>
               </button>
             )
          })}
        </div>
      </div>

      {/* Floating Particles Container */}
      <AnimatePresence>
        {particles.map(p => (
          <motion.div
             key={p.id}
             initial={{ opacity: 1, y: p.y, x: p.x, scale: p.isCrit ? 0.8 : 0.5 }}
             animate={{ opacity: 0, y: p.y - (p.isCrit ? 150 : 120), scale: p.isCrit ? 1.5 : 1.2 }}
             exit={{ opacity: 0 }}
             transition={{ duration: p.isCrit ? 1.2 : 1, ease: 'easeOut' }}
             className={`pointer-events-none fixed z-50 text-xl lg:text-2xl font-black ${p.isCrit ? 'text-red-400 drop-shadow-[0_0_15px_rgba(248,113,113,1)]' : 'text-white drop-shadow-[0_0_10px_rgba(34,211,238,1)]'}`}
             style={{ willChange: 'transform, opacity' }}
          >
             {p.isCrit ? 'CRITICAL ' : ''}+{formatNumber(p.value)}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<string | null>(null);

  useEffect(() => {
     const u = localStorage.getItem('logged_in_user');
     if (u) {
       setUser(u);
       initAbly(u);
     }
  }, []);

  const handleLogin = (username: string) => {
     setUser(username);
     localStorage.setItem('logged_in_user', username);
     initAbly(username);
  }

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('logged_in_user');
    if (ablyClient) {
      ablyClient.close();
      ablyClient = null;
    }
  }

  if (!user) return <Auth onLogin={handleLogin} />;
  return <GameView username={user} onLogout={handleLogout} />;
}
