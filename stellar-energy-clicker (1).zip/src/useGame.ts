import { useState, useEffect, useRef, useCallback } from 'react';
import { BUILDINGS, ACHIEVEMENTS, PRESTIGE_UPGRADES } from './gameData';
import { getBuildingCost } from './utils';

export interface GameState {
  energy: number;
  totalEnergy: number; // energy produced this run
  lifetimeEnergy: number; // energy produced across all runs
  clicks: number;
  buildings: Record<string, number>;
  upgrades: Record<string, boolean>;
  achievements: Record<string, boolean>;
  prestigeCurrency: number;
  prestigeUpgrades: Record<string, boolean>;
  startTime: number;
  lastSave: number;
  cps: number;
}

const initialState: GameState = {
  energy: 0,
  totalEnergy: 0,
  lifetimeEnergy: 0,
  clicks: 0,
  buildings: {},
  upgrades: {},
  achievements: {},
  prestigeCurrency: 0,
  prestigeUpgrades: {},
  startTime: Date.now(),
  lastSave: Date.now(),
  cps: 0
};

export function useGame(username: string) {
  const [state, setState] = useState<GameState>(initialState);
  const [loaded, setLoaded] = useState(false);
  const [cps, setCps] = useState(0);
  const [clickPower, setClickPower] = useState(1);
  const [recentAchievements, setRecentAchievements] = useState<string[]>([]);
  
  const [combo, setCombo] = useState(1);
  const comboRef = useRef(1);
  const lastClickTimeRef = useRef(0);

  const stateRef = useRef(state);
  stateRef.current = state;
  
  const cpsRef = useRef(cps);
  cpsRef.current = cps;

  const saveKey = `cosmic_clicker_save_${username}`;

  // Load Game
  useEffect(() => {
    const saved = localStorage.getItem(saveKey);
    if (saved) {
      try {
         const parsed = JSON.parse(saved) as Partial<GameState>;
         const now = Date.now();
         const lastSave = parsed.lastSave || now;
         const offlineSeconds = (now - lastSave) / 1000;
         const offlineGain = (parsed.cps || 0) * offlineSeconds;
         
         const loadedState: GameState = {
           ...initialState,
           ...parsed,
           achievements: parsed.achievements || {},
           prestigeUpgrades: parsed.prestigeUpgrades || {},
           prestigeCurrency: parsed.prestigeCurrency || 0,
           lifetimeEnergy: parsed.lifetimeEnergy || parsed.totalEnergy || 0,
         };
         
         loadedState.energy += offlineGain;
         loadedState.totalEnergy += offlineGain;
         loadedState.lifetimeEnergy += offlineGain;
         loadedState.lastSave = now;
         
         setState(loadedState);
         stateRef.current = loadedState;
      } catch(e) {
         console.error("Save corrupted", e);
      }
    } else {
       setState(initialState);
       stateRef.current = initialState;
    }
    setLoaded(true);
  }, [saveKey]);

  // Check achievements interval
  useEffect(() => {
    if (!loaded) return;
    const interval = setInterval(() => {
       const st = stateRef.current;
       const totalB = Object.values(st.buildings as Record<string, number>).reduce((a: number, b: number) => a + b, 0) as number;
       
       let unlockedAct = false;
       const newAchs: string[] = [];
       const nextAchs = { ...st.achievements };

       ACHIEVEMENTS.forEach(ach => {
          if (!nextAchs[ach.id]) {
             let unlocked = false;
             if (ach.reqType === 'clicks' && st.clicks >= ach.reqAmount) unlocked = true;
             if (ach.reqType === 'energy' && st.totalEnergy >= ach.reqAmount) unlocked = true;
             if (ach.reqType === 'totalBuildings' && totalB >= ach.reqAmount) unlocked = true;
             if (ach.reqType === 'building' && ach.reqId && (st.buildings[ach.reqId] || 0) >= ach.reqAmount) unlocked = true;
             
             if (unlocked) {
                nextAchs[ach.id] = true;
                newAchs.push(ach.name);
                unlockedAct = true;
             }
          }
       });

       if (unlockedAct) {
          setState(prev => ({ ...prev, achievements: nextAchs }));
          if (newAchs.length > 0) {
             setRecentAchievements(prev => [...prev, ...newAchs]);
             setTimeout(() => {
                setRecentAchievements(prev => prev.filter(x => !newAchs.includes(x)));
             }, 5000);
          }
       }
    }, 2000);
    return () => clearInterval(interval);
  }, [loaded]);

  // Calculate CPS
  useEffect(() => {
    if (!loaded) return;
    let newCps = 0;
    Object.entries(state.buildings).forEach(([bId, rawCount]) => {
       const count = rawCount as number;
       const bData = BUILDINGS.find(b => b.id === bId);
       if (!bData) return;
       let bProd = bData.baseProd * count;

       let mult = 1;
       if (state.upgrades[`${bId}_tier1`]) mult *= 2;
       if (state.upgrades[`${bId}_tier2`]) mult *= 2;
       if (state.upgrades[`${bId}_tier3`]) mult *= 2;
       
       newCps += (bProd * mult);
    });

    // Apply prestige CPS multipliers
    let prestigeCpsMult = 1;
    PRESTIGE_UPGRADES.forEach(pu => {
       if (pu.effectType === 'cps_multiplier' && state.prestigeUpgrades[pu.id]) {
          prestigeCpsMult += pu.effectValue;
       }
    });
    newCps *= prestigeCpsMult;
    
    setCps(newCps);

    let newClickPower = 1;
    let clickCpsMod = 0;
    if (state.upgrades['click_tier1']) clickCpsMod += 0.01;
    if (state.upgrades['click_tier2']) clickCpsMod += 0.05;
    if (state.upgrades['click_tier3']) clickCpsMod += 0.10;
    
    const cursorCount = state.buildings['b1'] || 0;
    newClickPower += (cursorCount * 0.1); 
    newClickPower += (newCps * clickCpsMod);

    // Apply prestige click multipliers
    let prestigeClickMult = 1;
    PRESTIGE_UPGRADES.forEach(pu => {
       if (pu.effectType === 'click_multiplier' && state.prestigeUpgrades[pu.id]) {
          prestigeClickMult += pu.effectValue;
       }
    });
    newClickPower *= prestigeClickMult;

    setClickPower(newClickPower);
  }, [state.buildings, state.upgrades, state.prestigeUpgrades, loaded]);

  // Game Loop
  useEffect(() => {
     if (!loaded) return;
     let lastTime = performance.now();
     let animationFrameId: number;

     const tick = (time: number) => {
        const delta = time - lastTime;
        if (delta >= 100) { 
           const currentCps = cpsRef.current;
           if (currentCps > 0) {
             const energyGain = currentCps * (delta / 1000);
             setState(prev => ({
                ...prev,
                energy: prev.energy + energyGain,
                totalEnergy: prev.totalEnergy + energyGain,
                lifetimeEnergy: prev.lifetimeEnergy + energyGain
             }));
           }
           
           if (time - lastClickTimeRef.current > 1500 && comboRef.current > 1) {
              comboRef.current = 1;
              setCombo(1);
           }
           
           lastTime = time;
        }
        animationFrameId = requestAnimationFrame(tick);
     }
     animationFrameId = requestAnimationFrame(tick);
     return () => cancelAnimationFrame(animationFrameId);
  }, [loaded]); 

  // Autosave
  useEffect(() => {
     if (!loaded) return;
     const interval = setInterval(() => {
        const saveState = { ...stateRef.current, cps: cpsRef.current, lastSave: Date.now() };
        localStorage.setItem(saveKey, JSON.stringify(saveState));
     }, 10000);
     return () => clearInterval(interval);
  }, [loaded, saveKey]);

  const manualClick = useCallback(() => {
     const now = performance.now();
     if (now - lastClickTimeRef.current < 1000) {
         comboRef.current = Math.min(comboRef.current + 0.05, 5.0); // max 5x combo
     } else {
         comboRef.current = 1.0;
     }
     lastClickTimeRef.current = now;
     setCombo(comboRef.current);

     const isCrit = Math.random() < 0.1;
     const critMult = isCrit ? 7 : 1;
     const gain = clickPower * comboRef.current * critMult;
     
     setState(prev => ({
        ...prev,
        energy: prev.energy + gain,
        totalEnergy: prev.totalEnergy + gain,
        lifetimeEnergy: prev.lifetimeEnergy + gain,
        clicks: prev.clicks + 1
     }));
     return { gain, isCrit, combo: comboRef.current };
  }, [clickPower]);

  const buyBuilding = useCallback((id: string, baseCost: number) => {
     let success = false;
     setState(prev => {
       const count = prev.buildings[id] || 0;
       const cost = getBuildingCost(baseCost, count);
       if (prev.energy >= cost) {
          success = true;
          return {
             ...prev,
             energy: prev.energy - cost,
             buildings: { ...prev.buildings, [id]: count + 1 }
          };
       }
       return prev;
     });
     return success;
  }, []);

  const buyUpgrade = useCallback((id: string, cost: number) => {
     let success = false;
     setState(prev => {
       if (prev.energy >= cost && !prev.upgrades[id]) {
          success = true;
          return {
             ...prev,
             energy: prev.energy - cost,
             upgrades: { ...prev.upgrades, [id]: true }
          };
       }
       return prev;
     });
     return success;
  }, []);

  const buyPrestigeUpgrade = useCallback((id: string, cost: number) => {
     let success = false;
     setState(prev => {
       if (prev.prestigeCurrency >= cost && !prev.prestigeUpgrades[id]) {
          success = true;
          return {
             ...prev,
             prestigeCurrency: prev.prestigeCurrency - cost,
             prestigeUpgrades: { ...prev.prestigeUpgrades, [id]: true }
          };
       }
       return prev;
     });
     return success;
  }, []);

  const calculatePrestigeGain = useCallback(() => {
     // example formula: square root of total energy (in millions)
     const amount = Math.floor(Math.sqrt(stateRef.current.totalEnergy / 1000000));
     return amount > 0 ? amount : 0;
  }, []);

  const prestigeReset = useCallback(() => {
     const st = stateRef.current;
     const gain = Math.floor(Math.sqrt(st.totalEnergy / 1000000));
     if (gain <= 0) return;

     if(confirm(`Are you sure you want to prestige? You will reset your universe to gain ${gain} Dark Matter.`)) {
         let startingEnergy = 0;
         PRESTIGE_UPGRADES.forEach(pu => {
            if (pu.effectType === 'starting_energy' && st.prestigeUpgrades[pu.id]) {
               startingEnergy += pu.effectValue;
            }
         });

         const newState: GameState = {
            ...initialState,
            lifetimeEnergy: st.lifetimeEnergy,
            achievements: st.achievements,
            prestigeCurrency: st.prestigeCurrency + gain,
            prestigeUpgrades: st.prestigeUpgrades,
            energy: startingEnergy
         };
         setState(newState);
         stateRef.current = newState;
         localStorage.setItem(saveKey, JSON.stringify(newState));
     }
  }, [saveKey]);

  const hardReset = useCallback(() => {
     if(confirm("Are you sure you want to completely reset ALL progress including Prestige?")) {
         localStorage.removeItem(saveKey);
         window.location.reload();
     }
  }, [saveKey]);

  return { 
     state, cps, clickPower, combo, loaded, recentAchievements, 
     manualClick, buyBuilding, buyUpgrade, buyPrestigeUpgrade, 
     calculatePrestigeGain, prestigeReset, hardReset 
  };
}
